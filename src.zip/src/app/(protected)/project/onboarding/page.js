'use client';
import React from 'react';
import ProjectOnboardingForm from '@/modules/project/ProjectOnboarding';


export default function Page() {
  return (
    <>
      <div className="px-4 lg:px-6">
        
<ProjectOnboardingForm />
      </div>
    </>
  );
}
      
     
 
