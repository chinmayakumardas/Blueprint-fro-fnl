import CauseDashboard from "@/modules/cause/causeDashboard";


export default function Page() {
  return (
    <>
      

     <CauseDashboard/>

    </>
  );
}