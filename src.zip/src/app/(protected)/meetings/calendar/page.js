import CalendarContainer from "@/modules/meetings/calendar/CalendarConatiner";


export default function Page() {
  return (
    <>
      <div className="px-4 lg:px-6">
<CalendarContainer/>
      </div>
    </>
  );
}