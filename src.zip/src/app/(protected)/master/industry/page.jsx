
import Industry from "@/modules/master/IndustryMaster";



export default function page() {
 

  return (
  
  
      <Industry/> 
   
  );
}
